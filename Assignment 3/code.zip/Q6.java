

import java.util.Scanner;

//import q6package1.StudentData;

class StudentDataExtended extends q6package1.StudentData
{
	private String location;
	
	/*StudentDataExtended()
	{
		this.setName("");
		this.setName("");
		this.setName("");
		this.location="";
	}*/
	
	public void addDetails(String roll,String id,String name,String location)
	{
		System.out.println(roll+" "+id.length()+" "+name.length()+" "+location);
		String temp="";
		for(int i=0;i<id.length();i++)
		{
			temp=temp+id.charAt(i);
		}
		System.out.println(temp+" "+id.length()+" "+name.length()+" "+location);
		this.setName(roll);
		this.setName(temp);
		this.setName(name);
		this.location=location;
	}
	
	void printDetails()
	{
		System.out.print(this.getId()+" "+this.getName()+" "+this.location);
	}
	
}

public class Q6
{
	public static void main(String[] args)
	{
		Scanner input=new Scanner(System.in);
		System.out.print("Enter the number of students :");
		int n=input.nextInt();
		input.nextLine();
		
		StudentDataExtended []stud=new StudentDataExtended[n];
		StudentDataExtended temp=new StudentDataExtended();
		
		for(int i=0;i<n;i++)
		{
			System.out.print("Enter the details of Student "+(i+1)+" (id, name, location):\n");
			
		
			String id=input.next();
			String name=input.next();
			String location=input.next();
			
			System.out.println(id+" "+name+" "+location);
			
			stud[i]=new StudentDataExtended();
			stud[i].addDetails("abc",id,name,location);
			//stud[i]=temp;
			stud[i].printDetails();
		}
		
	}
}


