package q6package1;

public class StudentData
{
	private String roll;
	private String id;
	private String name;
	
	public String getRoll()
	{
		return this.roll;
	}
	
	public String getId()
	{
		return this.id;
	}
	
	public String getName()
	{
		return this.name;
	}
	
	public void setRoll(String roll)
	{
		this.roll=roll;
	}
	
	public void setId(String id)
	{
		this.id=id;
	}
	
	public void setName(String name)
	{
		this.name=name;
	}
	
}
